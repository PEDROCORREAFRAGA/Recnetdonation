<?php

class User
{
    public $primary_key;
    public $user_exists;
    public $password;
    public $user_id;
    public $entity;
    public $seller = false;
    public $loginAndRedirect = false;

    private $api;

    public function setApi($api)
    {
        $this->api = $api;
    }

    public function checkUser($userId)
    {
        $auth = $this->api->call('auth', 'POST', [
            'user_id'=>$userId
        ]);
        switch($auth->erro->codigo){
            case "050":
                $this->user_exists = false;
                $this->user_id = $userId;
                break;
            case "007":
                $this->user_exists = true;
                $this->user_id = $auth->objeto->conta_usuario;
                break;
            default:
                throw new Exception('Não foi possível verificar se usuário existe',9002);
        }
    }

    public function createAccount($userId, $password){
        $account = $this->api->call('conta', 'POST', [
            'user_id' => $userId,
            'senha' => $password
        ]);
        if($account->successo === '0'){
            throw new Exception($account->erro->mensagem, $account->erro->codigo);
        }
        $this->user_id = $userId;
    }

    public function attemptLogin($user, $password)
    {
        $attempt = $this->api->call('auth', 'POST', [
            'user_id'=>$user,
            'senha'=>$password
        ]);

        if($attempt->successo === '1'){
            $this->user_id = $attempt->objeto->conta_usuario;
            setcookie('user_token',$attempt->objeto->user_token);
            // @todo usar operador e não vendedor
            $this->seller = $attempt->objeto->nome_vendedor !== null;
            $this->loginAndRedirect = true;
        }
    }

    public function isAuth()
    {
        if($_COOKIE['user_token'] === null || $_COOKIE['user_token'] === '') return false;
        $user_token = $_COOKIE['user_token'];
        $auth = $this->api->call('auth/' . $user_token, 'GET');
        return $auth->successo === '1';
    }

    public function fetchEntity()
    {
        $user_token = $_COOKIE['user_token'];
        $fetch = $this->api->call('cadastro/' . $user_token, 'GET');
        if($fetch->successo === '1'){
            $this->entity = $fetch->objeto;
            $this->user_id = $fetch->objeto->user_id;
        }
    }

    public function resetPassword($email)
    {
        $mailContent = "<div style='border:1px solid #aaa; width:100%; max-width:700px; font-family:arial; margin:0px auto;'>
                    <img src='https://recnet.com.br/doacoes/assets/img/headerMail.jpg' width='100%' alt='Doações RecNet'><br>
                    <div style='padding:30px 50px;'>
                        <div style='font-size:30px; color:#aaa; width:100%; text-align:center; font-weight:bold; margin:40px 0px;'>
                            <p><strong>Sua nova senha</strong></p>
                        </div>
                        <div style='font-size:20px; color:#aaa; display:block; width:100%; text-align:left;'>
                            Criamos uma nova senha para seu acesso ao <strong>RecNet</strong>.<br><br><br>
                            <p style='font-size:30px; color:#aaa; width:100%; text-align:center; font-weight:bold; margin:40px 0px;'>[SENHA]</p>
                            <a href='https://recnet.com.br/doacoes/login.php' target='_blank' style='background:#ddd; padding:5px; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px;  text-decoration:none;'>Clique aqui para acessar.</a><br><br><br>
                        </div>
                        <div style='font-size:16px; color:#aaa;'>
                            Atenciosamente,<br>
                            Equipe RecNet.
                        </div><br><br>
                    <div style='font-size:12px; color:#aaa;'>
                        <p>Copyright RecNet ".date("Y")." | Todos os direitos reservados <span style='font-size:16px;'>•</span> <a href='https://recnet.com.br/'>www.recnet.com.br</a></p>
                    </div>
                </div>
                </div>";
        return $this->api->call('novasenha/'.$email, 'PUT', [
            "assunto" => "Sua nova senha RecNet",
            "mensagem" => $mailContent
        ]);
    }
}