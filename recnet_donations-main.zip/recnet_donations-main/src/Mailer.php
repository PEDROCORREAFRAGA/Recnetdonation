<?php
use Postmark\PostmarkClient;

class Mailer
{
    public $client;
    public $fromEmail;
    public $toEmail;
    public $subject;
    public $htmlBody;
    public $textBody;
    public $tag;
    public $trackOpens;
    public $trackLinks;
    public $messageStream;
    public $mailContent;

    public function __construct()
    {
        $this->client = new PostmarkClient(APP_ENV["POSTMARK_SERVER_TOKEN"]);
        $this->fromEmail = "recnet@recnet.com.br";
        $this->trackOpens = true;
        $this->trackLinks = "None";
        $this->messageStream = "outbound";
    }

    public function mailHtml($text)
    {
        return '<html lang="pt-br">
            <head>
                <meta charset="UTF-8">
                <title>'._('RecNet - Doações').'</title>
            </head>
            <body>
            '.$text.'
            </body>';
    }

    public function prepareNewAccountEmail($to, $name, $password, $coupomObject)
    {
        $this->subject = _("Sua conta na RecNet");
        $this->toEmail = $to;
        $prize = json_decode($coupomObject['Prize']);
        $drawDate = new DateTime($coupomObject['DrawDate']);
        $drawDateDisplay = $drawDate->format('d/m/Y');
        $this->mailContent = "<div style='border:1px solid #aaa; width:100%; max-width:700px; font-family:arial; margin:0px auto;'>
                    <img src='" . APP_ENV['APPLICATION_URL'] . "/assets/img/headerMail.jpg' width='100%' alt='" . _('Doações RecNet') . "'><br>
                    <div style='padding:30px 50px;'>
                        <div style='font-size:30px; color:#aaa; width:100%; text-align:center; font-weight:bold; margin:40px 0px;'>
                            <p>" . _('Olá') . " " . $name . ".</p>
                            <p><strong>"._('Obrigado por sua doação!')."</strong></p>
                        </div>
                        <div style='font-size:20px; color:#aaa; display:block; width:100%; text-align:left;'>
                            "._('Criamos uma nova conta para você na')." <strong>RecNet</strong>.<br>"._('Use a seguinte senha para acessar e ver as informações do seu pagamento e seu cupom:')."<br><br><br>
                            <p style='font-size:30px; color:#aaa; width:100%; text-align:center; font-weight:bold; margin:40px 0px;'>" . $password . "</p>
                            <a href='" . APP_ENV['APPLICATION_URL'] . "/login.php' target='_blank' style='background:#ddd; padding:5px; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px;  text-decoration:none;'>"._('Clique aqui para acessar.') . "</a><br><br><br>
                            <p><strong>"._('O sorteio de')." ".($prize->name != ''?_($prize->name) :_('um brinde surpresa'))." ("._('ou produto de valor equivalente').") "._('será no dia')." ".$drawDateDisplay.".</strong></p>
                            <p>" . _('Anunciaremos o cupom vencedor no site')." ". APP_ENV['APPLICATION_URL'] .". ". _('Boa sorte!') . "</p>
                        </div>                        
                        <div style='font-size:18px; color:#aaa; display:block; width:100%; text-align:left;'>
                           <p>" . _('O sorteio segue as regras que podem ser consultadas na') . " <a href='" . APP_ENV['APPLICATION_URL'] . "/regulamento.php'>" . _('página de regulamento dos sorteios') . "</a></p>
                        </div>                        
                        <div style='font-size:16px; color:#aaa;'>
                            "._('Atenciosamente').",<br>
                            "._('Equipe RecNet')."
                        </div><br><br>
                    <div style='font-size:12px; color:#aaa;'>
                        <p>" . _('Copyright RecNet') ." ".date("Y")." | "._('Todos os direitos reservados')." <span style='font-size:16px;'>•</span> <a href='" . APP_ENV['APPLICATION_URL'] . "'>" . APP_ENV['APPLICATION_URL'] . "</a></p>
                    </div>
                </div>
                </div>";
    }

    public function preparePaymentConfirmationEmail($to, $name, $coupomObject)
    {
        $this->subject = _("Pagamento confirmado - RecNet");
        $this->toEmail = $to;
        $prize = json_decode($coupomObject['Prize']);
        $drawDate = new DateTime($coupomObject['DrawDate']);
        $drawDateDisplay = $drawDate->format('d/m/Y');
        $this->mailContent = "<div style='border:1px solid #aaa; width:100%; max-width:700px; font-family:arial; margin:0px auto;'>
                    <img src='" . APP_ENV['APPLICATION_URL'] . "/assets/img/headerMail.jpg' width='100%' alt='" . _('Doações RecNet') . "'><br>
                    <div style='padding:30px 50px;'>
                        <div style='font-size:30px; color:#aaa; width:100%; text-align:center; font-weight:bold; margin:40px 0px;'>
                            <p>" . _('Olá') . " " . $name . ".</p>
                            <p><strong>"._('Obrigado por sua doação!')."</strong></p>
                        </div>
                        <div style='font-size:20px; color:#aaa; display:block; width:100%; text-align:left;'>
                            "._('Segue o link para acesso aos detalhes do seu pagamento e seu cupom:') . "<br><br><br>
                            <a href='" . APP_ENV['APPLICATION_URL'] . "/login.php' target='_blank' style='background:#ddd; padding:5px; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px;  text-decoration:none;'>"._('Clique aqui para vê-los.') . "</a>
                            <p><strong>"._('O sorteio de')." ".($prize->name != ''?_($prize->name) :_('um brinde surpresa'))." ("._('ou produto de valor equivalente').") "._('será no dia')." ".$drawDateDisplay.".</strong></p>
                            <p>" . _('Anunciaremos o cupom vencedor no site') ." ". APP_ENV['APPLICATION_URL'] .". ". _('Boa sorte!') . "</p>
                        </div>                        
                        <div style='font-size:18px; color:#aaa; display:block; width:100%; text-align:left;'>
                           <p>" . _('O sorteio segue as regras que podem ser consultadas na') . " <a href='" . APP_ENV['APPLICATION_URL'] . "/regulamento.php'>" . _('página de regulamento dos sorteios') . "</a></p>
                        </div>
                        <div style='font-size:16px; color:#aaa;'>
                            "._('Atenciosamente').",<br>
                            "._('Equipe RecNet')."
                        </div><br><br>
                    <div style='font-size:12px; color:#aaa;'>
                        <p>" . _('Copyright RecNet') ." ".date("Y") . " | "._('Todos os direitos reservados')." <span style='font-size:16px;'>•</span> <a href='" . APP_ENV['APPLICATION_URL'] . "'>" . APP_ENV['APPLICATION_URL'] . "</a></p>
                    </div>
                </div>
                </div>";
    }

    public function send()
    {
        $this->htmlBody = $this->mailHtml($this->mailContent);
        $this->textBody = strip_tags(str_replace('<br>', "\n", $this->htmlBody));
        return $this->client->sendEmail(
            $this->fromEmail,
            $this->toEmail,
            $this->subject,
            $this->htmlBody,
            $this->textBody,
            $this->tag,
            $this->trackOpens,
            NULL, // Reply To
            NULL, // CC
            NULL, // BCC
            NULL, // Header array
            NULL, // Attachment array
            $this->trackLinks,
            NULL, // Metadata array
            $this->messageStream);
    }
}