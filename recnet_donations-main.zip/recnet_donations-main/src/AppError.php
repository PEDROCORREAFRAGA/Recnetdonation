<?php
use Monolog\Handler\StreamHandler;
use Monolog\Logger;

class AppError
{
    public $logger;

    public function __construct()
    {
        $this->logger = new Logger('main');
        $this->logger->pushProcessor(new \Monolog\Processor\IntrospectionProcessor);
        $this->logger->setTimezone(new DateTimeZone('America/Sao_Paulo'));
        $this->logger->pushHandler(new StreamHandler(APP_ENV['LOG_PATH']), Logger::WARNING);
    }
}