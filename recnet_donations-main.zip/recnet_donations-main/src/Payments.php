<?php
require 'Db.php';

class Payments
{
    public function getPaymentsByUser($email)
    {
        $db = new Db();
        return $db->fetchDonorEmailProccesses($email);
    }
}