<?php


class Helper
{
    public static function p($str){
        echo '<pre>';
        print_r($str);
        echo '</pre>';
    }

    public static function px($str){
        self::p($str);
        exit();
    }

    public static function fakePaymentObject(){

        return (object)[
            'id' => rand(1233655551,3214567890),
            'status' => 'approved',
            'status_detail' => 'accredited',
            'date_created' => date('c'),
            'transaction_amount' => (float)rand(5,999),
            'installments'=>1,
            'payment_method_id'=>'master',
            'token' => rand(1233655551,3214567890),
            'payer' => [
                'id' => rand(893655551,984567890)
            ],
            'error'=>0
        ];
    }

    public static function isPost($params){
        if($_SERVER['REQUEST_METHOD'] !== 'POST') return false;
        $paramValid = false;
        if(is_array($params)){
            foreach ($params as $param){
                $paramValid = self::isParamValid($_POST[$param]);
            }
        } else $paramValid = self::isParamValid($_POST[$params]);
        return $paramValid;
    }

    public static function isParamValid($param, $type='string')
    {
        if(isset($param) !== true) return false;
        $isValid = false;
        switch ($type){
            case 'string':
                $isValid = $param !== "";
                break;
            case 'int':
                $isValid = is_integer((int)$param);
                break;
        }
        return $isValid;
    }
}