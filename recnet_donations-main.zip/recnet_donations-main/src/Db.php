<?php
require_once 'src/Helper.php';

class Db
{
    private $conn;

    /**
     * Db constructor.
     * @throws Exception
     */
    public function __construct()
    {
        $this->conn = new mysqli(APP_ENV['DATABASE_HOST'], APP_ENV['DATABASE_USER'], APP_ENV['DATABASE_PASSWORD'], APP_ENV['DATABASE_NAME']);
        $this->conn->set_charset("UTF-8");
        if(mysqli_connect_errno()){
            throw new Exception(mysqli_connect_error(), mysqli_connect_errno());
        }
    }

    /**
     * Save payment attempt
     * @param $donorName donor name (coupon owner)
     * @param $donorEmail donor e-mail (coupon owner and auth idenitifier)
     * @param $payer card holder information
     * @param $payment payment object
     * @param $paymentResponse response from payment gateway
     * @return mysqli_stmt
     * @throws Exception
     */
    public function savePaymentAttempt($donorName, $donorEmail, $payer, $payment, $paymentResponse)
    {
        $stmt = $this->conn->prepare("INSERT INTO proccesses (
            donor_name, 
            donor_email,
            email,
            doc_type,
            doc_number,
            issuer,
            installments,
            transaction_amount,
            trid,
            payment_method_id,
            description,
            token,
            payment_gateway_response
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
        if(!$stmt)
            throw new Exception($stmt->error, $stmt->errno);

        $stmt->bind_param("ssssssidissss",
            $donorName,
            $donorEmail,
            $payer->email,
            $payer->identification['type'],
            $payer->identification['number'],
            $payment->issuer_id,
            $payment->installments,
            $payment->transaction_amount,
            $payment->id,
            $payment->payment_method_id,
            $payment->description,
            $payment->token,
            json_encode($paymentResponse)
        );
        if(!$stmt)
            throw new Exception($stmt->error, $stmt->errno);

        if(!$stmt->execute())
            throw new Exception($stmt->error, $stmt->errno);

        return $stmt;
    }

    /**
     * Look for user or saves new
     * @param $userEmail user e-mail
     * @return integer selected or created user's id
     * @throws Exception
     */
    public function getOrInsertUser($userEmail)
    {
        $selectSt = $this->conn->prepare('SELECT id from users where email = ?');
        $selectSt->bind_param('s', $userEmail);
        if(!$selectSt->execute())
            throw new Exception($selectSt->error, $selectSt->errno);

        $result = $selectSt->get_result();
        if($result->num_rows === 1){
            return $result->fetch_assoc()['id'];
        }else{
            $stmt = $this->conn->prepare("INSERT INTO users (email) VALUES (?)");
            $stmt->bind_param("s",$userEmail);
            if(!$stmt->execute())
                throw new Exception($stmt->error, $stmt->errno);
            return $stmt->insert_id;
        }
    }

    /**
     * Fetch all payments from table proccesses filtered by donor e-mail
     * @param $donorEmail
     * @return mixed
     * @throws Exception
     */
    public function fetchDonorEmailPayments($userEmail){
        $stmt = $this->conn->prepare('SELECT id, transaction_amount, payment_gateway_response, created_at FROM proccesses WHERE donor_email=? ORDER BY created_at DESC');
        $stmt->bind_param('s', $userEmail);
        $stmt->execute();
        $result = $stmt->get_result();
        if(!$result)
            throw new Exception($stmt->error,$stmt->errno);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Fetch a single payment from table proccesses filtered by id
     * @param $id
     * @return mixed
     */
    public function fetchPayment($id){
        if($stmt = $this->conn->prepare('SELECT id, donor_name, donor_email, email, doc_type, doc_number, issuer, transaction_amount, trid, payment_method_id, description, payment_gateway_response, created_at FROM proccesses WHERE id=?')){
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $result = $stmt->get_result();
            return $result->fetch_assoc();
        } else {
            // @todo tratar exceção se houver falha de statement
            die('error stmt');
        }
    }

    /**
     * Save user to a random coupon and returns it
     * @param $series
     * @param $userId
     * @return bool
     */
    public function getNewCoupon($series, $userId, $proccessId)
    {
        $query = 'UPDATE coupons SET owner_id=?, proccess_id=? WHERE coupons.id = 
                    (SELECT * FROM (SELECT id from coupons where series_id=? and owner_id IS NULL ORDER BY RAND()) as a LIMIT 0,1)';
        if($stmt = $this->conn->prepare($query)){
            $stmt->bind_param('iii', $userId, $proccessId, $series);
            return $stmt->execute();
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::px($stmt);
        }
    }

    /**
     * Get coupons by proccess id
     * @param $proccessId
     * @return array|null
     */
    public function getCoupomByProccess($proccessId)
    {
        $query = 'SELECT c.number AS "Number", c.created_at AS "DateCreated", 
                        s.number AS "Series", s.draw_date AS "DrawDate", s.prize AS "Prize" FROM 
                        coupons c JOIN series s on c.series_id = s.id where c.proccess_id=?';
        if($stmt = $this->conn->prepare($query)){
            $stmt->bind_param('s', $proccessId);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::px($stmt);
        }
    }

    /**
     * Get coupons by id with owner name and id
     * @param $id
     * @return array|null
     */
    public function getCoupomById($id)
    {
        $query = 'SELECT c.id "Id", c.number "Number", c.created_at "DateCreated", 
                        s.number "Series", s.draw_date "DrawDate",
                        p.donor_name "OwnerName", p.donor_email "OwnerEmail" FROM 
                        coupons c JOIN series s on c.series_id = s.id
                        JOIN proccesses p ON c.proccess_id = p.id
                        WHERE c.id=? AND c.owner_id IS NOT NULL';
        if($stmt = $this->conn->prepare($query)){
            $stmt->bind_param('i', $id);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::px($stmt);
        }
    }

    public function dashboardFetchTransactions()
    {
        $query = 'SELECT transaction_amount, DATE_FORMAT(created_at, "%d//%m//%Y") FROM proccesses where 
                     trid IS NOT NULL AND created_at BETWEEN CURDATE() - INTERVAL 7 DAY AND CURDATE()';
        if($res = $this->conn->query($query)){
            return $res;
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::px($this->conn->error_list);
        }
    }

    public function dashboardFetchCoupons()
    {
        $query = 'SELECT owner_id, DATE_FORMAT(created_at, "%d//%m//%Y") FROM coupons where 
                    owner_id IS NOT NULL AND created_at BETWEEN CURDATE() - INTERVAL 7 DAY AND CURDATE()';
        if($res = $this->conn->query($query)){
            return $res;
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::px($this->conn->error_list);
        }
    }

    public function fetchAllTransactions()
    {
        $query = 'SELECT id, created_at, donor_name, transaction_amount, payment_gateway_response FROM proccesses 
                    ORDER BY created_at DESC';
        if($res = $this->conn->query($query)){
            return $res;
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::px($this->conn->error_list);
        }
    }

    public function fetchAllCoupons()
    {
        $query = 'SELECT c.id, c.number "Number", s.number "Series", p.donor_name "Owner" FROM
                    coupons c JOIN series s on c.series_id = s.id
                    JOIN proccesses p on c.proccess_id = p.id
                    WHERE c.owner_id IS NOT NULL
                    ORDER BY c.created_at DESC';
        if($res = $this->conn->query($query)){
            return $res;
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::px($this->conn->error_list);
        }
    }

    public function fetchAllDonors()
    {
        $query = 'SELECT u.id "Id", p.donor_name "Name", p.donor_email "E-mail", u.created_at "Creation Date", p.transaction_amount "Amount", p.created_at "Donation Date" FROM
                    proccesses p JOIN users u ON p.donor_email = u.email 
                    WHERE p.trid IS NOT NULL GROUP BY u.id ORDER BY u.id DESC';
        if($res = $this->conn->query($query)){
            return $res;
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::px($this->conn->error_list);
        }
    }

    public function fetchDonorInfo($id)
    {
        $query = 'SELECT u.id "Id", p.donor_name "Name", p.donor_email "E-mail", u.created_at "DateCreated" FROM
                    proccesses p JOIN users u ON p.donor_email = u.email 
                    WHERE u.id=?';
        if($stmt = $this->conn->prepare($query)){
            $stmt->bind_param('i', $id);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::p($stmt->error_list);
            Helper::px($this->conn->error_list);
        }
    }

    public function fetchDonorCoupons($donorId)
    {
        $query = 'SELECT c.id "Id", p.transaction_amount "Amount", c.number "Number", s.number "Series", s.draw_date "DrawDate" FROM
                    coupons c JOIN series s on c.series_id = s.id
                    JOIN users u ON c.owner_id = u.id
                    JOIN proccesses p on c.proccess_id = p.id
                    WHERE c.owner_id=?
                    ORDER BY c.id DESC';
        if($stmt = $this->conn->prepare($query)){
            $stmt->bind_param('i', $donorId);
            $stmt->execute();
            $result = $stmt->get_result();
            return $result->fetch_all(MYSQLI_ASSOC);
        } else {
            // @todo tratar exceção se houver falha de statement
            Helper::px($this->conn->error_list);
        }
    }
}