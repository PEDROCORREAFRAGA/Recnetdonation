<?php

class Api
{
    private $token;
    public $url;

    public function __construct(){
        $this->url = APP_ENV['API_URL'];
        $this->token = APP_ENV['API_TOKEN'];
    }
    /**
     * Acesso à API Paguetudo
     *
     * @param string $endpoint URL para o ending point utilizado
     * @param string $method Método utilizado
     * @param array/null $data Dados para a API
     * @param string $parse Tipo de retorno
     * @return objeto
     */
    public function call($endpoint, $method, $data = null, $parse = true)
    {
        if (!$endpoint) {
            throw new Exception('Endpoint não foi informado', 9000);
        }
        $data = $parse ? $this->parse($data) : $data;
        $headers = [
            'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: Custom ' . $this->getToken(),
            strtoupper($method) == 'PUT' ? 'Content-Length:' . strlen($data) : ''
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->url . $endpoint);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        if (!$result = curl_exec($ch)) {
            throw new Exception(curl_error($ch),9001);
        } else {
            return json_decode($result);
        }
    }

    /**
     * Converter informação em UTF8
     *
     * @param array $param Parâmetros para conversão em UTF8
     * @return array
     */
    public function utf8ize($param)
    {
        if (is_array($param)) {
            foreach ($param as $k => $v) {
                $param[$k] = $this->utf8ize($v);
            }
        } else if (is_string($param) && mb_detect_encoding($param) === 'ISO-8859-1') {
            return utf8_encode($param);
        }
        return $param;
    }

    /**
     * Converter informação em UTF8 e codificá-la em JSON
     *
     * @param type $data Informação para conversão
     * @return type
     */
    function parse($data)
    {
        if (!$data) {
            return null;
        }
        return json_encode($data);
    }

    /**
     * Setar valor de URL da Api
     */
    public function setUrl($url=''){
        $this->url=$url;
    }

    /**
     * Retornar a URL da Api
     */
    public function getUrl(){
        return $this->url;
    }

    /**
     * Setter de $token.
     * @param $token valor de um token
     */
    public function setToken($token){
        $this->token=$token;
    }

    /**
     * Getter de $token
     */
    public function getToken(){
        return $this->token;
    }
}