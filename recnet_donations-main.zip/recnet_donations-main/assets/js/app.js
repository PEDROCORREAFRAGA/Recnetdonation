let submitPaymentForm = false;
let cookies_path = '';
function userLogout(){
    document.cookie = "user_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=recnet.com.br;";
}
if(document.querySelector('#user-logout') !== null)
    document.querySelector('#user-logout').onclick = () => { userLogout(); window.location.assign('login.php') }

function showQrCode(){
    let qrHolder = document.getElementById("qrCode")
    let qrcode = new QRCode(qrHolder, {
        text: qrHolder.dataset.trid+'|'+qrHolder.dataset.date,
        width: 145,
        height: 145,
        colorDark : "#000000",
        colorLight : "#ffffff",
        correctLevel : QRCode.CorrectLevel.H
    });
    qrHolder.querySelector('img').classList.add('mx-auto','mx-sm-0');
}

function inputShowError(elmSelector, errMessage){
    let elm = document.querySelector(elmSelector);
    let elmInfo = document.querySelector(elm.dataset.targetmsg);
    elm.classList.add('border-2','border-danger');
    elmInfo.classList.remove('d-none');
    elmInfo.innerHTML = errMessage;
    elm.onfocus = () => {inputClearError(elm)}
}

function inputClearError(elm){
    let elmInfo = document.querySelector(elm.dataset.targetmsg);
    elm.classList.remove('border-2','border-danger');
    elmInfo.classList.add('d-none');
    elmInfo.innerHTML = '';
}

function clearAllInputMessages(){
    let inputs =  document.querySelectorAll('.form-control');
    inputs.forEach((e) => {e.classList.remove('border-2', 'border-danger')});
    let textAlerts = document.querySelectorAll('.recnet-input-error');
    textAlerts.forEach((e) => {e.classList.add('d-none')});
}

function userAcceptedCookies(){
    let cookies = document.cookie;
    let cookiesAccepted = cookies.indexOf("recnet_cookies_accepted") > -1;
    let notificationElement = document.querySelector("#cookies-notification");
    if(notificationElement === null) return;
    if(cookiesAccepted){
        notificationElement.classList.add('d-none');
        document.body.classList.remove('showing-cookie-notification');
    }
    else{
        notificationElement.classList.remove('d-none');
        document.body.classList.add('showing-cookie-notification');
    }

    submitPaymentForm = cookiesAccepted;
}

userAcceptedCookies();

if(document.querySelectorAll('.recnet-cookies-accept') !== null){
        document.querySelectorAll('.recnet-cookies-accept').forEach( (e) => e.onclick = () => {
            var date = new Date();
            date.setTime(date.getTime() + (365 * 24 * 60 * 60 * 1000));
            document.cookie = "recnet_cookies_accepted=true; expires=" + date.toGMTString() +"; path=" + cookies_path;
        }
    )
}

function verifyCookieAcceptance(event){
    if(!submitPaymentForm){
        event.preventDefault();
        $("#modal-alert-cookies-accept").modal('show');
        return false;
    }
}

if(document.querySelectorAll('.recnet-form-cookie-dependent') !== null){
    document.querySelectorAll('.recnet-form-cookie-dependent').forEach( (e) => e.onsubmit = (e) => {
            verifyCookieAcceptance(e)
        }
    )
}