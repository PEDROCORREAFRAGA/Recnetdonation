window.Mercadopago.getIdentificationTypes();
document.getElementById('cardNumber').addEventListener('change', guessPaymentMethod);

function guessPaymentMethod(event) {
   let cardnumber = document.getElementById("cardNumber").value;
   if (cardnumber.length >= 6) {
       let bin = cardnumber.substring(0,6);
       window.Mercadopago.getPaymentMethod({
           "bin": bin
       }, setPaymentMethod);
   }
};

function setPaymentMethod(status, response) {
   if (status == 200) {
       let paymentMethod = response[0];
       document.getElementById('paymentMethodId').value = paymentMethod.id;

       getIssuers(paymentMethod.id);
   } else {
       // alert(`payment method info error: ${response}`);
       showCardError(response);
   }
}

function getIssuers(paymentMethodId) {
    window.Mercadopago.getIssuers(
        paymentMethodId,
        setIssuers
    );
 }
 
 function setIssuers(status, response) {
    if (status == 200) {
        let issuerSelect = document.getElementById('issuer');
        response.forEach( issuer => {
            let opt = document.createElement('option');
            opt.text = issuer.name;
            opt.value = issuer.id;
            issuerSelect.appendChild(opt);
        });

    } else {
        // alert(`issuers method info error: ${response}`);
        showCardError(response);
    }
 }

doSubmit = false;
document.getElementById('paymentForm').addEventListener('submit', getCardToken);
function getCardToken(event){
   event.preventDefault();
   if(!doSubmit){
       if(submitPaymentForm === false)
           return false;
       clearAllInputMessages();
       let $form = document.getElementById('paymentForm');
       window.Mercadopago.createToken($form, setCardTokenAndPay);
       return false;
   }
};

function setCardTokenAndPay(status, response) {
   if (status == 200 || status == 201) {
       let form = document.getElementById('paymentForm');
       let card = document.createElement('input');
       card.setAttribute('name', 'token');
       card.setAttribute('type', 'hidden');
       card.setAttribute('value', response.id);
       form.appendChild(card);
       doSubmit=true;
       form.submit();
   } else {
       // alert("Verify filled data!\n"+JSON.stringify(response, null, 4));
       showCardError(response);
   }
};

function showCardError(res){
    if(res.cause){
        res.cause.map( e => {
            switch(e.code){
                case "221":
                    inputShowError("#cardholderName", "Nome do titular não pode ser vazio");
                    break;
                case "324":
                    inputShowError("#docNumber", "Número de documento inválido");
                    break;
                case "325":
                    inputShowError("#cardExpirationMonth", "Mês de vencimento inválido");
                    break;
                case "326":
                    inputShowError("#cardExpirationYear", "Ano de vencimento inválido");
                    break;
                case "E301":
                    inputShowError("#cardNumber", "Número do cartão inválido");
                    break;
                case "E302":
                    inputShowError("#securityCode", "Código de segurança inválido");
                    break;
            }
        })
    }
}