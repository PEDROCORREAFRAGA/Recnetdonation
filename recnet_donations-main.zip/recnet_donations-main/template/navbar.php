<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="https://recnet.com.br/"><img src="https://recnet.com.br/assets/images/Logo%20RecNet.png" alt="RecNet" title=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="https://recnet.com.br/index.html"><?=_('Home')?> <span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://recnet.com.br/page1.html"><?=_('Quem Somos')?> <span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://recnet.com.br/page2.html"><?=_('Segurança')?> <span class="sr-only"></span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="https://recnet.com.br/doacoes"><?=_('Doações')?> <span class="sr-only">(<?=_('atual')?>)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://recnet.com.br/index.html#form4-5"><?=_('Contato')?> <span class="sr-only"></span></a>
                </li>
            </ul>
        </div>

        <div class="recnet-lang-flags">
            <a <?= $lang == 'pt_BR' ?'class="current-language"' :'href="?lang=pt_BR"'?>"><img src="assets/img/br-icon.png" title="Português" alt="Português"></a>
            <a <?= $lang == 'en_US' ?'class="current-language"' :'href="?lang=en_US"'?>"><img src="assets/img/us-icon.png" title="English" alt="English"></a>
        </div>
    </div>
</nav>