<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="https://recnet.com.br/"><img src="https://recnet.com.br/assets/images/Logo%20RecNet.png" alt="RecNet" title=""></a>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="text-light pull-right">
                <h1><?=_('Painel Administrativo')?></h1>
                <p><?=_('Doações Childfund')?></p>
            </div>
        </div>

        <div class="recnet-lang-flags">
            <a <?= $lang == 'pt_BR' ?'class="current-language"' :'href="?lang=pt_BR"'?>"><img src="assets/img/br-icon.png" title="Português" alt="Português"></a>
            <a <?= $lang == 'en_US' ?'class="current-language"' :'href="?lang=en_US"'?>"><img src="assets/img/us-icon.png" title="English" alt="English"></a>
        </div>
    </div>
</nav>