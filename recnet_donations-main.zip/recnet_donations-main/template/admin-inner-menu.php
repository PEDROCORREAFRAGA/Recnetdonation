<ul class="list-group">
    <li class="list-group-item"><a href="admin-area.php"><?=_('Dashboard')?></a></li>
    <li class="list-group-item"><a href="admin-transactions.php"><?=_('Transações')?></a></li>
    <li class="list-group-item"><a href="admin-donors.php"><?=_('Doadores')?></a></li>
    <li class="list-group-item"><a href="admin-coupons.php"><?=_('Cupons')?></a></li>
</ul>
<div class="mt-3 card">
    <p class="card-body"><i class="bi-person-circle"></i> <?php echo $v->nome?> <small><a id="user-logout" class="user-logout">(<?=_('sair')?>)</a></small>
    </p>
</div>