<div id="cookies-notification" class="alert alert-secondary mb-0 d-none">
    <div class="row">
        <div class="col-3 recnet-text-bigger text-right">
            <i class="bi bi-info-circle"></i>
        </div>
        <div class="col-9">
            <p>
                <?=_('Utilizamos cookies em nosso site para garantir uma experiência de navegação segura.')?><br />
                <?=_('Clicando em "aceitar", você permite o uso desses cookies.')?> <a href="termos.php#politica-de-cookies"><?=_('Saiba mais em nossos termos de uso')?></a>
            </p>
            <button class="btn btn-success recnet-cookies-accept"><i class="bi bi-check"></i> <?=_('Aceitar e continuar')?></button>
        </div>
    </div>
</div>