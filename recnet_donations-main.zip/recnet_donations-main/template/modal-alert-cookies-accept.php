<div class="modal" tabindex="-1" id="modal-alert-cookies-accept">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?=_('Importante!')?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p><?=_('Oferecemos um ambiente seguro para suas transações e consulta a cupons através de cookies.')?></p>
                <p><?=_('Para continuar, você precisa aceitar o uso de cookies no site.')?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success recnet-cookies-accept" data-dismiss="modal"><i class="bi bi-check"></i> <?=_('Aceitar cookies e continuar')?></button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?=_('Fechar')?></button>
            </div>
        </div>
    </div>
</div>